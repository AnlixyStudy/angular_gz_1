import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TaskCard } from './task-card/task-card';
import { NgFor } from '@angular/common';

export interface Task {
  id:number,
  title:string,
  deadline:Date,
  isCompleted:boolean
}

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, TaskCard, NgFor],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  tasks:Task[] = [
    {id:1, title: 'какать', deadline: new Date('2026-03-10'), isCompleted: false},
    {id:2, title: 'кушать', deadline: new Date('2026-03-14'), isCompleted: true},
    {id:3, title: 'готовть', deadline: new Date('2026-02-15'), isCompleted: false}
  ]
}
