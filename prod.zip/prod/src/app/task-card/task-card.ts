import { Component, Input } from '@angular/core';
import { UpperCasePipe, DatePipe, NgIf } from '@angular/common';
import { App, Task } from '../app';

@Component({
  selector: 'app-task-card',
  imports: [UpperCasePipe, DatePipe, NgIf],
  templateUrl: './task-card.html',
  styleUrl: './task-card.css',
})
export class TaskCard {
  @Input() task!:Task;
  
}
